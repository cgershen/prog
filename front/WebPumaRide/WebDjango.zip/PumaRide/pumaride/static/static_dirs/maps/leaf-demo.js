// See post: http://asmaloney.com/2014/01/code/creating-an-interactive-map-with-leaflet-and-openstreetmap/

//var map = L.map('map').setView([markers[0].lat, markers[0].lng], 13);
var map = new L.Map('map');    

L.tileLayer( 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  subdomains: ['a', 'b', 'c'],
}).addTo( map )

//Define an array of Latlng objects (points along the line)
var polylinePoints = [
   new L.LatLng(51.51032167, -0.187084072),
   new L.LatLng(51.51019814, -0.187030437),
   new L.LatLng(51.51013137, -0.187845822),
   new L.LatLng(51.50457546, -0.185415744),
   new L.LatLng(51.50476244, -0.181875224),
   new L.LatLng(51.50457546, -0.179622177),
   new L.LatLng(51.50409462, -0.175459380),
   new L.LatLng(51.50368057, -0.174365042),
   new L.LatLng(51.50299938, -0.174729820),
   new L.LatLng(51.50213117, -0.174686903),
   new L.LatLng(51.50199760, -0.177412030),
   new L.LatLng(51.50179725, -0.180373197),
   new L.LatLng(51.50143660, -0.180351735),
];
         
var polylineOptions = {
   color: '#f50909',
   //color: '#14d807',
   weight: 6,
   opacity: 0.6
};

var polyline = new L.Polyline(polylinePoints, polylineOptions);

map.addLayer(polyline);  

// zoom the map to the polyline
map.fitBounds(polyline.getBounds());


var myURL = jQuery( 'script[src$="leaf-demo.js"]' ).attr( 'src' ).replace( 'leaf-demo.js', '' )

var myIcon = L.icon({
  iconUrl: myURL + 'images/pin24.png',
  iconRetinaUrl: myURL + 'images/pin48.png',
  iconSize: [29, 24],
  iconAnchor: [9, 21],
  popupAnchor: [0, -14]
})

for ( var i=0; i < markers.length; ++i )
{
 L.marker( [markers[i].lat, markers[i].lng], {icon: myIcon} )
  .bindPopup( '<a href="' + markers[i].url + '" target="_blank">' + markers[i].name + '</a>' )
  .addTo( map );
}

